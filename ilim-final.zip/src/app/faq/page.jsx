import Link from 'next/link'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'

export const metadata = {
  title: 'Frequently Asked Questions',
  description:
    'Answers to the most common questions about ILIM International School: language immersion, the admissions process, academics, tuition, and what ILIM graduates become. Charlotte, NC private school FAQ.',
}

const faqs = [
  {
    category: 'Language & Immersion',
    items: [
      {
        q: 'What four languages does ILIM teach?',
        a: 'ILIM students learn Arabic, Mandarin (Simplified), Spanish, and English. These four languages represent the economies, cultures, and markets that define the next 50 years of global commerce — and together reach over 75% of the world\'s population.',
      },
      {
        q: 'Why these four languages specifically?',
        a: 'Arabic connects students to the Gulf economies, North Africa, and the Middle East — some of the fastest-growing markets in the world. Mandarin is the most spoken native language on earth. Spanish is the second most spoken language in the United States and is official in 21 countries. English is the global academic and commercial standard. Together, these four create a child who can operate without a translator in virtually any business environment.',
      },
      {
        q: 'My child doesn\'t speak any of these languages. Is that a problem?',
        a: 'No. ILIM is designed for children starting with zero exposure. Language immersion is most effective when it begins before a child has linguistic habits to unlearn. Most ILIM students start with no background in Arabic, Mandarin, or Spanish and develop genuine conversational fluency through daily instruction.',
      },
      {
        q: 'What is the language acquisition window, and why does it matter?',
        a: 'The language acquisition window refers to the period in early childhood — roughly from birth through age 12 — when the human brain is most receptive to learning language at a native level. During this window, children can develop accent-free pronunciation and natural fluency in multiple languages simultaneously. After the window closes, language learning becomes a mechanical process that rarely produces the same results. Every year a child spends in a monolingual environment is a year of that window spent.',
      },
      {
        q: 'Will my child be truly fluent, or just conversational?',
        a: 'ILIM students develop genuine working fluency across all four languages — reading, writing, speaking, and listening. Graduates communicate comfortably in all four and can present, write, and reason in each one. True fluency takes years of immersive practice, and that\'s exactly what ILIM provides from day one.',
      },
      {
        q: 'How does immersion work in a classroom with young children?',
        a: 'Instruction at ILIM rotates through languages throughout the day. Different subjects are taught in different languages. Teachers are native or near-native speakers. The environment reinforces language naturally — through conversation, instruction, play, and project work — rather than through translation. Children don\'t "switch" between languages consciously; they absorb them as distinct systems.',
      },
    ],
  },
  {
    category: 'Academics',
    items: [
      {
        q: 'Will my child keep up academically if they\'re learning in four languages?',
        a: 'Yes. ILIM\'s academic model is what we call Academics-Plus: the same rigorous core instruction in reading, writing, mathematics, and science that any top private school provides — then four languages, cultural competency, public speaking, and project leadership on top. Language immersion does not replace academic rigor; it runs alongside it. ILIM students consistently perform two grade levels above their peers on standardized assessments — not because testing is the focus, but as a result of deep, engaged learning.',
      },
      {
        q: 'What is Montessori, and how does ILIM use it?',
        a: 'Montessori is an evidence-based educational approach developed by Dr. Maria Montessori that emphasizes child-led exploration, hands-on learning, and individualized pacing. ILIM uses Montessori principles in its early childhood programs (ages 2–Kindergarten) to create an environment where children develop independence, focus, and intrinsic motivation. In elementary and middle school, ILIM transitions to project-based learning while maintaining the Montessori spirit of individual agency.',
      },
      {
        q: 'What is project-based learning?',
        a: 'Project-based learning (PBL) is a teaching model where students gain knowledge and skills by working for an extended period on a complex, real-world challenge or question. At ILIM, PBL is how students apply what they\'re learning across subjects — a student might research, present, and solve a real problem while using multiple languages, mathematics, writing, and collaborative skills simultaneously.',
      },
      {
        q: 'What is the student-teacher ratio?',
        a: 'ILIM maintains a 1:8 student-teacher ratio. This is by design. A small ratio means every child receives individual attention, teachers actually know each student\'s strengths and gaps, and no one falls through the cracks.',
      },
    ],
  },
  {
    category: 'Admissions',
    items: [
      {
        q: 'How do I enroll my child at ILIM?',
        a: 'Begin by joining the waitlist at admissions.ilimschool.com/waitlist. There is no fee and no commitment at that stage. When a seat becomes available for your child\'s program year, our admissions team will reach out to schedule a personal campus tour. After the tour, families who want to move forward submit a formal application and pay a $250 non-refundable observation fee, which reserves a spot for Observation Week.',
      },
      {
        q: 'What is Observation Week?',
        a: 'Observation Week is a one-week period during which your child attends ILIM as a provisional student. They participate in the daily classroom environment — language instruction, project time, group activities — while our educators observe their readiness, engagement, and fit. At the end of the week, ILIM\'s admissions team issues an enrollment determination letter.',
      },
      {
        q: 'Is ILIM enrollment guaranteed after the tour?',
        a: 'No. ILIM enrollment is selective at every stage. A tour does not guarantee an application invitation, and an Observation Week does not guarantee enrollment. This selectivity is intentional — it protects the experience for every enrolled family and ensures every student in the classroom belongs there.',
      },
      {
        q: 'Can my child enroll mid-year?',
        a: 'Mid-year enrollment is possible if seats are available. Contact our admissions team directly to discuss your situation.',
      },
      {
        q: 'What age does ILIM accept students?',
        a: 'ILIM accepts students beginning at age 2 (Early Preschool) through 8th grade (approximately age 14).',
      },
    ],
  },
  {
    category: 'Tuition & Fees',
    items: [
      {
        q: 'How much is tuition at ILIM?',
        a: 'ILIM\'s tuition reflects the premium instruction, small class ratios, and outcomes the school delivers. Tuition is annual with monthly installment options. Full tuition details are available on our Tuition page or by request from the admissions team after your waitlist application.',
      },
      {
        q: 'What does the $250 application fee cover?',
        a: 'The $250 fee is paid after your campus tour if both you and ILIM want to proceed. It covers the formal application review and reserves your child\'s place in Observation Week. The fee is non-refundable.',
      },
      {
        q: 'Does ILIM offer financial aid or scholarships?',
        a: 'ILIM offers a limited number of merit-based and need-based financial assistance arrangements. Contact the admissions office directly to discuss your situation.',
      },
    ],
  },
]

// Full FAQPage schema
const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.flatMap((cat) =>
    cat.items.map((item) => ({
      '@type': 'Question',
      name: item.q,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.a,
      },
    }))
  ),
}

export default function FAQPage() {
  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <Navigation />

      {/* Hero */}
      <section
        style={{ background: 'linear-gradient(160deg, #060D1A 0%, #112040 100%)' }}
        className="pt-36 pb-20"
      >
        <div className="max-w-4xl mx-auto px-6">
          <div className="gold-label mb-4">Frequently asked questions</div>
          <h1
            className="text-cream-50 mb-4 leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(2rem, 4vw, 3.25rem)', fontWeight: 500 }}
          >
            Everything parents ask before the tour.
          </h1>
          <p className="text-cream-200/60 leading-relaxed max-w-2xl">
            Real questions from real parents considering ILIM. If yours isn't here, email us at{' '}
            <a href="mailto:contactus@ilimschool.com" className="text-gold-500 hover:text-gold-400 transition-colors">
              contactus@ilimschool.com
            </a>
          </p>
        </div>
      </section>

      {/* FAQ content */}
      <section className="bg-cream-50 py-20">
        <div className="max-w-4xl mx-auto px-6">
          <div className="flex flex-col gap-16">
            {faqs.map((cat) => (
              <div key={cat.category}>
                <div className="gold-label mb-6">{cat.category}</div>
                <div className="flex flex-col gap-8">
                  {cat.items.map(({ q, a }) => (
                    <div key={q} className="border-b border-navy-900/10 pb-8">
                      <h2
                        className="text-navy-900 mb-3 text-lg leading-snug"
                        style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
                      >
                        {q}
                      </h2>
                      <p className="text-navy-600 text-sm leading-relaxed">{a}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section
        style={{ background: 'linear-gradient(135deg, #0A1628 0%, #112040 100%)' }}
        className="py-20 text-center"
      >
        <div className="max-w-2xl mx-auto px-6">
          <h2
            className="text-cream-50 mb-4"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: '2rem', fontWeight: 500 }}
          >
            Still have questions?
          </h2>
          <p className="text-cream-200/60 mb-8">
            The best answers come from a campus visit. Join the waitlist and our admissions team will be in touch.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/waitlist" className="btn-gold">
              Join the Waitlist
            </Link>
            <a href="mailto:contactus@ilimschool.com" className="btn-outline">
              Email admissions
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
