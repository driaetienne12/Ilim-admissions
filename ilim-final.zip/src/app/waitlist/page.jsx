'use client'
import { useState } from 'react'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'

const programs = [
  'Early Preschool (Ages 2–3)',
  'Primary (Age 4 – Kindergarten)',
  'Elementary (1st–6th Grade)',
  'Middle School (7th–8th Grade)',
]

const howHeard = [
  'Word of mouth / friend',
  'Google search',
  'Instagram',
  'Facebook',
  'LinkedIn',
  'Local parenting group',
  'Business network / event',
  'Other',
]

export default function WaitlistPage() {
  const [step, setStep] = useState(1)
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({
    parentFirstName: '',
    parentLastName: '',
    email: '',
    phone: '',
    childName: '',
    childDOB: '',
    program: '',
    currentSchool: '',
    howHeard: '',
    message: '',
  })

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }))

  const handleSubmit = (e) => {
    e.preventDefault()
    // In production: POST to your CRM / Kit API
    console.log('Waitlist submission:', form)
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <main>
        <Navigation />
        <section
          style={{ background: 'linear-gradient(160deg, #060D1A 0%, #112040 100%)' }}
          className="min-h-screen flex items-center justify-center px-6"
        >
          <div className="text-center max-w-lg">
            <div className="text-gold-500 text-6xl mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>✦</div>
            <h1
              className="text-cream-50 mb-4"
              style={{ fontFamily: "'Playfair Display', serif", fontSize: '2.5rem', fontWeight: 500 }}
            >
              You're on the waitlist.
            </h1>
            <p className="text-cream-200/60 leading-relaxed mb-4">
              Thank you, {form.parentFirstName}. We've added your family to the ILIM waitlist for the{' '}
              <span className="text-gold-500">{form.program}</span> program.
            </p>
            <p className="text-cream-200/50 text-sm leading-relaxed mb-10">
              Check your inbox — we'll send a confirmation shortly. When a seat becomes available for {form.childName}'s program year, our admissions team will reach out directly to schedule a personal tour.
            </p>
            <p className="text-cream-200/30 text-xs">
              In the meantime, explore the programs at{' '}
              <a href="/programs/early-preschool" className="text-gold-500/60 hover:text-gold-500">
                admissions.ilimschool.com
              </a>
            </p>
          </div>
        </section>
        <Footer />
      </main>
    )
  }

  return (
    <main>
      <Navigation />

      <section
        style={{ background: 'linear-gradient(160deg, #060D1A 0%, #112040 100%)' }}
        className="pt-36 pb-16"
      >
        <div className="max-w-2xl mx-auto px-6">
          <div className="gold-label mb-4">Join the waitlist</div>
          <h1
            className="text-cream-50 mb-4 leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 500 }}
          >
            Reserve your child's place.
          </h1>
          <p className="text-cream-200/60 text-base leading-relaxed">
            ILIM enrollment is selective and limited. The waitlist is how our admissions team tracks families approaching an enrollment year. No fee. No commitment. Just step one.
          </p>
        </div>
      </section>

      <section className="bg-cream-50 py-20">
        <div className="max-w-2xl mx-auto px-6">
          <form onSubmit={handleSubmit} className="flex flex-col gap-8">
            {/* Parent info */}
            <div>
              <div className="gold-label mb-5">Parent / Guardian</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                    First name *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.parentFirstName}
                    onChange={set('parentFirstName')}
                    className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                    placeholder="Dria"
                  />
                </div>
                <div>
                  <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                    Last name *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.parentLastName}
                    onChange={set('parentLastName')}
                    className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                    placeholder="Etienne"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                  Email address *
                </label>
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={set('email')}
                  className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                  placeholder="you@email.com"
                />
              </div>
              <div>
                <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                  Phone number
                </label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={set('phone')}
                  className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                  placeholder="(704) 000-0000"
                />
              </div>
            </div>

            {/* Child info */}
            <div>
              <div className="gold-label mb-5">Your child</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                    Child's first name *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.childName}
                    onChange={set('childName')}
                    className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                    placeholder="First name"
                  />
                </div>
                <div>
                  <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                    Date of birth *
                  </label>
                  <input
                    type="date"
                    required
                    value={form.childDOB}
                    onChange={set('childDOB')}
                    className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Program */}
            <div>
              <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                Program of interest *
              </label>
              <select
                required
                value={form.program}
                onChange={set('program')}
                className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
              >
                <option value="" disabled>Select program</option>
                {programs.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            {/* Current school */}
            <div>
              <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                Where is your child currently enrolled? (optional)
              </label>
              <input
                type="text"
                value={form.currentSchool}
                onChange={set('currentSchool')}
                className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
                placeholder="School name or 'Not yet in school'"
              />
            </div>

            {/* How heard */}
            <div>
              <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                How did you find ILIM?
              </label>
              <select
                value={form.howHeard}
                onChange={set('howHeard')}
                className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors"
              >
                <option value="" disabled>Select</option>
                {howHeard.map((h) => (
                  <option key={h} value={h}>{h}</option>
                ))}
              </select>
            </div>

            {/* Message */}
            <div>
              <label className="block text-navy-600 text-xs uppercase tracking-wider mb-2 font-medium">
                Anything you'd like us to know? (optional)
              </label>
              <textarea
                value={form.message}
                onChange={set('message')}
                rows={4}
                className="w-full border border-navy-900/20 bg-white px-4 py-3 text-navy-900 text-sm focus:outline-none focus:border-gold-500 transition-colors resize-none"
                placeholder="Questions, context about your child, timeline for enrollment..."
              />
            </div>

            {/* Disclaimer */}
            <p className="text-navy-400 text-xs leading-relaxed">
              Joining the waitlist does not guarantee enrollment or a tour invitation. ILIM's admissions team will reach out directly when seats are available for your child's program year. We treat every family's information with care and never sell or share your data.
            </p>

            <button type="submit" className="btn-gold w-full py-4 text-base">
              Submit Waitlist Application
            </button>
          </form>
        </div>
      </section>

      <Footer />
    </main>
  )
}
