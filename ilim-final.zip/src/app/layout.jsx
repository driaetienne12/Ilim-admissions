import './globals.css'

export const metadata = {
  metadataBase: new URL('https://admissions.ilimschool.com'),
  title: {
    default: 'ILIM School Admissions | 4-Language Immersion PreK–8th Grade Charlotte NC',
    template: '%s | ILIM School Admissions',
  },
  description:
    'ILIM International School in Charlotte, NC enrolls students ages 2–14 in a four-language immersion program — Arabic, Mandarin, Spanish, and English — with rigorous academics, Montessori foundations, and real-world leadership skills. Join our waitlist.',
  keywords: [
    'language immersion school Charlotte NC',
    'multilingual private school Charlotte',
    'quadrilingual school Charlotte',
    'Arabic Mandarin Spanish school Charlotte',
    'Montessori immersion Charlotte NC',
    'private school Charlotte NC admissions',
    'bilingual school Charlotte NC',
    'international school Charlotte NC',
    'ILIM School Charlotte',
    'ILIM admissions',
    'language school preschool Charlotte',
  ],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://admissions.ilimschool.com',
    siteName: 'ILIM School Admissions',
    title: 'ILIM School Admissions | 4-Language Immersion PreK–8th Grade Charlotte NC',
    description:
      'Your child will speak Arabic, Mandarin, Spanish, and English — fluently — by 8th grade. ILIM School in Charlotte, NC. Join the waitlist.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'ILIM International School Charlotte NC — 4-Language Immersion',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ILIM School Admissions | Charlotte NC',
    description: 'Your child will speak 4 languages by 8th grade. Join the ILIM waitlist.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
    },
  },
  alternates: {
    canonical: 'https://admissions.ilimschool.com',
  },
}

// JSON-LD Schema Markup
const schemaOrg = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'EducationalOrganization',
      '@id': 'https://admissions.ilimschool.com/#organization',
      name: 'ILIM International School',
      alternateName: 'ILIM School',
      url: 'https://ilimschool.com',
      sameAs: [
        'https://admissions.ilimschool.com',
        'https://www.facebook.com/ilimschool',
      ],
      logo: 'https://admissions.ilimschool.com/logo.png',
      description:
        'ILIM International School is a private Montessori-based language immersion school in Charlotte, NC, offering four-language education in Arabic, Mandarin, Spanish, and English for students ages 2 through 14.',
      foundingDate: '2021',
      numberOfEmployees: {
        '@type': 'QuantitativeValue',
        minValue: 10,
        maxValue: 50,
      },
      address: {
        '@type': 'PostalAddress',
        streetAddress: '601 N Polk St',
        addressLocality: 'Pineville',
        addressRegion: 'NC',
        postalCode: '28134',
        addressCountry: 'US',
      },
      geo: {
        '@type': 'GeoCoordinates',
        latitude: '35.0801',
        longitude: '-80.8912',
      },
      contactPoint: {
        '@type': 'ContactPoint',
        telephone: '+1-704-389-9408',
        contactType: 'admissions',
        email: 'contactus@ilimschool.com',
        availableLanguage: ['English', 'Arabic', 'Mandarin', 'Spanish'],
      },
      hasOfferCatalog: {
        '@type': 'OfferCatalog',
        name: 'ILIM School Programs',
        itemListElement: [
          {
            '@type': 'Course',
            name: 'Early Preschool Program',
            description:
              'Four-language immersion for children ages 2–3. Montessori-based early childhood environment with Arabic, Mandarin, Spanish, and English.',
            provider: { '@id': 'https://admissions.ilimschool.com/#organization' },
            educationalLevel: 'Preschool',
          },
          {
            '@type': 'Course',
            name: 'Primary Program',
            description:
              'Four-language immersion for children ages 4 through Kindergarten. Core academic foundations with language immersion and Reggio-Emilia approaches.',
            provider: { '@id': 'https://admissions.ilimschool.com/#organization' },
            educationalLevel: 'Kindergarten',
          },
          {
            '@type': 'Course',
            name: 'Elementary Immersion Program',
            description:
              'Full academic program in four languages for 1st through 6th grade. Project-based learning, entrepreneurship, and cultural competency.',
            provider: { '@id': 'https://admissions.ilimschool.com/#organization' },
            educationalLevel: 'Elementary School',
          },
          {
            '@type': 'Course',
            name: 'Middle School Program',
            description:
              'Advanced multilingual academics for 7th and 8th grade. Students graduate fluent in Arabic, Mandarin, Spanish, and English with leadership and public speaking skills.',
            provider: { '@id': 'https://admissions.ilimschool.com/#organization' },
            educationalLevel: 'Middle School',
          },
        ],
      },
    },
    {
      '@type': 'LocalBusiness',
      '@id': 'https://admissions.ilimschool.com/#localbusiness',
      name: 'ILIM International School',
      image: 'https://admissions.ilimschool.com/og-image.jpg',
      telephone: '+1-704-389-9408',
      email: 'contactus@ilimschool.com',
      address: {
        '@type': 'PostalAddress',
        streetAddress: '601 N Polk St',
        addressLocality: 'Pineville',
        addressRegion: 'NC',
        postalCode: '28134',
        addressCountry: 'US',
      },
      openingHoursSpecification: [
        {
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
          opens: '08:00',
          closes: '16:00',
        },
      ],
      priceRange: '$$$',
      currenciesAccepted: 'USD',
      url: 'https://ilimschool.com',
    },
    {
      '@type': 'Person',
      '@id': 'https://admissions.ilimschool.com/#founder',
      name: 'Dria Etienne',
      jobTitle: 'Founder & Head of School',
      affiliation: { '@id': 'https://admissions.ilimschool.com/#organization' },
      description:
        'Dria Etienne is the founder of ILIM International School, a serial entrepreneur, international business traveler, and mother who built the multilingual immersion school she could not find for her own children.',
      sameAs: ['https://www.linkedin.com/in/driaetienne'],
    },
    {
      '@type': 'WebSite',
      '@id': 'https://admissions.ilimschool.com/#website',
      url: 'https://admissions.ilimschool.com',
      name: 'ILIM School Admissions',
      publisher: { '@id': 'https://admissions.ilimschool.com/#organization' },
    },
  ],
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaOrg) }}
        />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
}
