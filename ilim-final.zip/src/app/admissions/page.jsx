import Link from 'next/link'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'

export const metadata = {
  title: 'Admissions Process',
  description:
    'How to apply to ILIM International School in Charlotte, NC. A selective, invitation-based enrollment process: waitlist, tour, observation week, and enrollment decision. Learn what to expect at every step.',
}

const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'How do I apply to ILIM School?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Begin by joining the waitlist at admissions.ilimschool.com. Once your child approaches an enrollment year, our admissions team will reach out to schedule a personal campus tour. After the tour, families who wish to proceed submit a formal application and pay the $250 observation fee, which reserves their child\'s spot for Observation Week.',
      },
    },
    {
      '@type': 'Question',
      name: 'What is Observation Week at ILIM?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Observation Week is a one-week period during which your child attends ILIM School in a supervised environment. Our educators observe your child\'s readiness, engagement, and fit within the ILIM community. Your child experiences the school firsthand. At the end of the week, ILIM\'s admissions team reviews all observations and issues an enrollment determination letter.',
      },
    },
    {
      '@type': 'Question',
      name: 'Is enrollment at ILIM guaranteed after the waitlist?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'No. ILIM enrollment is selective. Being on the waitlist does not guarantee a tour invitation, and a tour does not guarantee enrollment. Families are evaluated for fit, and students are evaluated during Observation Week. This selective process protects the community and the experience for every enrolled family.',
      },
    },
    {
      '@type': 'Question',
      name: 'What is the $250 application and observation fee?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'The $250 fee is paid after your family completes a campus tour and decides to move forward. It covers the formal application review and reserves your child\'s place for Observation Week. This fee is non-refundable.',
      },
    },
  ],
}

export default function AdmissionsPage() {
  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <Navigation />

      {/* Hero */}
      <section
        style={{ background: 'linear-gradient(160deg, #060D1A 0%, #112040 100%)' }}
        className="pt-36 pb-24"
      >
        <div className="max-w-4xl mx-auto px-6">
          <div className="gold-label mb-4">Admissions</div>
          <h1
            className="text-cream-50 mb-6 leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(2.2rem, 5vw, 3.75rem)', fontWeight: 500 }}
          >
            Every ILIM student is evaluated.<br />
            <em className="text-gold-500">Every family is chosen.</em>
          </h1>
          <p className="text-cream-200/60 text-lg leading-relaxed max-w-2xl">
            ILIM is not open enrollment. Seats are limited by design. Our 1:8 student-teacher ratio means every child in the classroom gets individual attention — and that means every admission decision matters.
          </p>
        </div>
      </section>

      {/* Process */}
      <section className="bg-cream-50 py-24">
        <div className="max-w-4xl mx-auto px-6">
          <div className="gold-label mb-4">The process</div>
          <h2
            className="text-navy-900 mb-14"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: '2rem', fontWeight: 500 }}
          >
            Six steps. No surprises.
          </h2>

          <div className="flex flex-col gap-0">
            {[
              {
                n: '01',
                title: 'Join the waitlist',
                time: 'Start here',
                detail:
                  'Submit your family\'s information through the waitlist form. No fee. No commitment. We use the waitlist to track families whose children are approaching enrollment age and to gauge demand for each program year.',
                cta: null,
              },
              {
                n: '02',
                title: 'Receive a tour invitation',
                time: 'By invitation',
                detail:
                  'When your child is approaching an enrollment year and seats are available, our admissions team will reach out to schedule a personal campus tour. Tour invitations are extended directly — you won\'t need to follow up.',
                cta: null,
              },
              {
                n: '03',
                title: 'Campus tour',
                time: 'Approx. 60 minutes',
                detail:
                  'You\'ll see the classrooms, meet a guide, and watch ILIM in action. Most families know within the first 20 minutes whether it\'s the right environment. The tour is for your benefit — you\'re evaluating us too.',
                cta: null,
              },
              {
                n: '04',
                title: 'Application + observation fee ($250)',
                time: 'Post-tour',
                detail:
                  'If both sides want to move forward, you\'ll submit a formal application and pay the $250 non-refundable fee. This fee reserves your child\'s spot in Observation Week and covers our admissions review. It signals mutual seriousness.',
                cta: null,
              },
              {
                n: '05',
                title: 'Observation Week',
                time: 'One school week',
                detail:
                  'Your child spends one full week at ILIM. They experience the environment as a participant — the languages, the classroom culture, the pace. Our educators observe their engagement, social readiness, and fit. This isn\'t a test they can pass or fail. It\'s a look at whether ILIM and your child are right for each other.',
                cta: null,
              },
              {
                n: '06',
                title: 'Enrollment decision',
                time: 'Within 5 business days',
                detail:
                  'ILIM\'s admissions team reviews the observation week and sends an enrollment determination letter. Accepted families receive an invitation to Parent Orientation and then complete their enrollment agreement and first tuition payment.',
                cta: null,
              },
            ].map((s, i) => (
              <div
                key={s.n}
                className={`flex gap-8 py-10 ${i < 5 ? 'border-b border-navy-900/10' : ''}`}
              >
                <div className="flex-shrink-0 pt-1">
                  <div className="step-number">{s.n}</div>
                </div>
                <div className="flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 mb-3">
                    <h3
                      className="text-navy-900 text-xl"
                      style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
                    >
                      {s.title}
                    </h3>
                    <span className="text-gold-600 text-xs uppercase tracking-widest font-medium">
                      {s.time}
                    </span>
                  </div>
                  <p className="text-navy-600 text-sm leading-relaxed">{s.detail}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-14 bg-navy-900 p-8 md:p-10">
            <div className="flex flex-col md:flex-row md:items-center gap-6 justify-between">
              <div>
                <h3
                  className="text-cream-100 mb-2 text-xl"
                  style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
                >
                  Ready to start?
                </h3>
                <p className="text-cream-200/50 text-sm">
                  The waitlist is free. Step one takes 2 minutes.
                </p>
              </div>
              <Link href="/waitlist" className="btn-gold whitespace-nowrap">
                Join the Waitlist
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* What we look for */}
      <section className="bg-cream-100 py-24">
        <div className="max-w-4xl mx-auto px-6">
          <div className="gold-label mb-4">What we look for</div>
          <h2
            className="text-navy-900 mb-8"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: '2rem', fontWeight: 500 }}
          >
            Fit matters more than test scores.
          </h2>
          <p className="text-navy-600 leading-relaxed mb-4">
            ILIM doesn't select students based on prior academic achievement alone. We're looking for children who are curious, engaged, and ready to learn across cultures — and families who are aligned with how we teach.
          </p>
          <p className="text-navy-600 leading-relaxed mb-10">
            The families who thrive at ILIM are the ones who chose the school because they share its values — not because it was the closest option or the only private school with an opening. That alignment is what Observation Week reveals.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {[
              {
                label: 'Family alignment',
                desc: 'Both parents understand and support the ILIM model. Education here is a partnership.',
              },
              {
                label: 'Child readiness',
                desc: 'Age-appropriate social and emotional readiness for a structured, immersive environment.',
              },
              {
                label: 'Investment mindset',
                desc: 'Families who see education as an investment in their child\'s future, not a cost to minimize.',
              },
              {
                label: 'Community fit',
                desc: 'ILIM is a community. We look for families who want to be part of one.',
              },
            ].map(({ label, desc }) => (
              <div key={label} className="bg-white p-6 border border-navy-900/5">
                <div className="divider-gold" />
                <h3
                  className="text-navy-900 mb-2"
                  style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.1rem', fontWeight: 500 }}
                >
                  {label}
                </h3>
                <p className="text-navy-600 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-cream-50 py-24">
        <div className="max-w-4xl mx-auto px-6">
          <div className="gold-label mb-4">Admissions FAQ</div>
          <h2
            className="text-navy-900 mb-10"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: '2rem', fontWeight: 500 }}
          >
            Common questions
          </h2>
          <div className="flex flex-col gap-8">
            {[
              {
                q: 'Is ILIM accepting applications right now?',
                a: 'The waitlist is always open. Active enrollment for specific program years is communicated directly to waitlisted families. Join the waitlist and our admissions team will reach out when seats are available for your child\'s age.',
              },
              {
                q: 'Can my child join if they don\'t speak any of the languages yet?',
                a: 'Yes. ILIM is designed for children with no prior exposure to Arabic, Mandarin, or Spanish. Immersion works best when it starts early and without prior conditioning. Most ILIM students begin with zero exposure and develop genuine fluency through daily instruction.',
              },
              {
                q: 'What if we\'re transferring from another school?',
                a: 'Transfer students are welcome to apply. The admissions process is the same regardless of where your child is currently enrolled. Observation Week helps us assess readiness for the ILIM environment specifically.',
              },
              {
                q: 'Do both parents need to attend the tour?',
                a: 'We strongly encourage it. School decisions at ILIM are typically made jointly, and the tour is the moment that makes the case in person. If one parent can\'t attend the initial tour, we can often arrange a follow-up.',
              },
              {
                q: 'What happens if my child isn\'t accepted after Observation Week?',
                a: 'Our admissions team will communicate the decision directly and, where possible, share context. Children who are not a fit at one point in time may be a stronger fit in a future program year. We handle every decision with respect for the family.',
              },
            ].map(({ q, a }) => (
              <div key={q} className="border-b border-navy-900/10 pb-8">
                <h3
                  className="text-navy-900 mb-3 text-lg"
                  style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
                >
                  {q}
                </h3>
                <p className="text-navy-600 text-sm leading-relaxed">{a}</p>
              </div>
            ))}
          </div>
          <div className="mt-10">
            <Link href="/faq" className="text-gold-600 font-medium text-sm">
              See all FAQ →
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
