import Link from 'next/link'
import Navigation from '@/components/Navigation'
import Footer from '@/components/Footer'

export const metadata = {
  title: 'Meet Dria Etienne — Founder of ILIM School',
  description:
    'Dria Etienne is the founder of ILIM International School in Charlotte, NC. A serial entrepreneur, international business traveler, and mother, she built the four-language immersion school she could not find for her own children.',
}

const founderSchema = {
  '@context': 'https://schema.org',
  '@type': 'Person',
  name: 'Dria Etienne',
  jobTitle: 'Founder & Head of School',
  affiliation: {
    '@type': 'EducationalOrganization',
    name: 'ILIM International School',
    url: 'https://ilimschool.com',
  },
  description:
    'Dria Etienne is the founder of ILIM International School, a serial entrepreneur, international business traveler, and mother who built the multilingual immersion school she could not find for her own children. ILIM opened in 2021 and has enrolled over 120 students in Charlotte, NC.',
  sameAs: ['https://www.linkedin.com/in/driaetienne'],
  worksFor: {
    '@type': 'EducationalOrganization',
    name: 'ILIM International School',
  },
}

export default function FounderPage() {
  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(founderSchema) }}
      />
      <Navigation />

      {/* Hero */}
      <section
        style={{ background: 'linear-gradient(160deg, #060D1A 0%, #112040 100%)' }}
        className="pt-36 pb-20"
      >
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-end">
            <div>
              <div className="gold-label mb-4">The founder</div>
              <h1
                className="text-cream-50 mb-4 leading-tight"
                style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(2.2rem, 4.5vw, 3.5rem)', fontWeight: 500 }}
              >
                Dria Etienne
              </h1>
              <div className="text-gold-500 text-sm uppercase tracking-widest mb-6">
                Founder & Head of School — ILIM International School
              </div>
              <p className="text-cream-200/60 leading-relaxed">
                Serial entrepreneur. International business traveler. Mother of ILIM students. She built the school she couldn't find.
              </p>
            </div>
            <div
              className="aspect-[3/4] bg-navy-800 flex items-center justify-center text-cream-200/10"
              style={{ borderLeft: '2px solid rgba(201,168,76,0.2)' }}
            >
              {/* Founder portrait placeholder */}
              <div className="text-center">
                <div className="text-5xl mb-3 text-gold-500/30" style={{ fontFamily: "'Playfair Display', serif" }}>D.E.</div>
                <div className="text-xs uppercase tracking-widest text-cream-200/20">Portrait</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="bg-cream-50 py-24">
        <div className="max-w-3xl mx-auto px-6">
          <div className="gold-label mb-6">The origin story</div>

          <div className="space-y-6 text-navy-700 leading-relaxed">
            <p className="text-xl" style={{ fontFamily: "'Playfair Display', serif" }}>
              Like every ILIM parent, Dria wanted more for her children than the standard model could offer.
            </p>

            <p>
              She'd built businesses. She'd sat in boardrooms in Dubai and Mexico City and São Paulo. She knew what it cost — in confidence, in opportunity, in access — to be the only person in the room who only spoke one language.
            </p>

            <p>
              She looked for a school that would give her children what she wished she'd had earlier. Rigorous academics, yes. But also four languages. Cultural fluency that came from daily immersion, not annual trips. A community of families who shared her values.
            </p>

            <p>She couldn't find it. So she built it.</p>

            <div className="border-l-2 border-gold-500 pl-6 my-10">
              <p
                className="text-navy-900 text-xl leading-relaxed"
                style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic' }}
              >
                "I was frustrated by cookie-cutter education — no critical thinking, no culture, no real-world preparation. So I built the school I couldn't find: immersive, multilingual, focused on real-world success, and most of all, fun."
              </p>
              <p className="text-navy-400 text-sm mt-4">— Dria Etienne, Founder</p>
            </div>

            <p>
              Before opening ILIM in 2021, Dria spent years consulting with experts, thought leaders, top schools, universities, and child development specialists. She studied what worked in the world's best multilingual education systems and built a model that could deliver those results in Charlotte.
            </p>

            <p>
              Since 2021, ILIM has enrolled over 120 students. They leave speaking Arabic, Mandarin, Spanish, and English — with the confidence to use all four.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {[
              {
                label: 'The entrepreneur perspective',
                detail: 'Dria built businesses before she built a school. That means ILIM is run with the discipline, intentionality, and long-term thinking of a founder — not a bureaucracy.',
              },
              {
                label: 'The parent\'s eye',
                detail: 'Her own children attend ILIM. She sees the school every day through a parent\'s lens — not just an administrator\'s. That\'s rare. And it shows.',
              },
              {
                label: 'The global perspective',
                detail: 'She\'s sat in rooms across four continents. She knows what multilingual fluency actually does for a person\'s trajectory — because she\'s watched it happen in real rooms with real stakes.',
              },
              {
                label: 'The community builder',
                detail: 'ILIM isn\'t just a school. It\'s a community Dria intentionally curated — families who parent with the same values, the same ambition, and the same belief that education is an investment, not an expense.',
              },
            ].map(({ label, detail }) => (
              <div key={label} className="bg-cream-100 p-6">
                <div className="divider-gold" />
                <h3
                  className="text-navy-900 mb-2 text-base"
                  style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
                >
                  {label}
                </h3>
                <p className="text-navy-600 text-sm leading-relaxed">{detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section
        style={{ background: 'linear-gradient(135deg, #0A1628 0%, #112040 100%)' }}
        className="py-20 text-center"
      >
        <div className="max-w-2xl mx-auto px-6">
          <h2
            className="text-cream-50 mb-4"
            style={{ fontFamily: "'Playfair Display', serif", fontSize: '2rem', fontWeight: 500 }}
          >
            See what she built.
          </h2>
          <p className="text-cream-200/60 mb-8">
            The best way to understand ILIM is to walk the campus. Join the waitlist and we'll be in touch to schedule a personal tour.
          </p>
          <Link href="/waitlist" className="btn-gold text-base px-10 py-4">
            Join the Waitlist
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  )
}
